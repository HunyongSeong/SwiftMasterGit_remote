//
//  DinoDinaApp.swift
//  DinoDina
//
//  Created by David Goggins on 2023/05/04.
//

import SwiftUI

@main
struct DinoDinaApp: App {
    var body: some Scene {
        WindowGroup {
//            BookVegetable()
//            MyTestView()
            ContentView()
        }
    }
}
