//
//  MyTestView.swift
//  DinoDina
//
//  Created by David Goggins on 2023/05/06.
//

import SwiftUI

struct MyTestView: View {
    @State private var showModal = false
    
    var body: some View {
        VStack{
            Text("'나타나라'버튼 누르면 모달 출력!")
            Button(action: {
                self.showModal = true
            }){
                Text("나타나라").bold()
            }
            .frame(width: 80, height: 30, alignment: .center)
            .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue))
            .font(.system(size: 16))
            .foregroundColor(Color.white)
            .sheet(isPresented: self.$showModal) {
                ModalView()
            } //Button 끝
        } //Vstack 끝
        
        
    }
}

struct ModalView: View {
    @Environment(\.presentationMode) var presentation
    
    var body: some View {
        VStack {
            Text("Modal view 등장")
            Button(action: {
                presentation.wrappedValue.dismiss()
            }) {
                Text("Modal view 닫기").bold()
            }
            .frame(width: 150, height: 30, alignment: .center)
            .background(RoundedRectangle(cornerRadius: 40).fill(Color.red))
            .font(.system(size: 16))
            .foregroundColor(Color.white)
        }
        .padding()
    }
}

struct MyTestView_Previews: PreviewProvider {
    static var previews: some View {
        MyTestView()
    }
}
