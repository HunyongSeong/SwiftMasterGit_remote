//
//  SwiftUIView.swift
//  DinoDina
//
//  Created by David Goggins on 2023/05/06.
//

import SwiftUI



struct FoodsSheet: View {
    @State private var sheet = false
    
    var body: some View {
        VStack {
            Button("Show Sheet"){
                sheet.toggle()
            }
            .sheet(isPresented: $sheet) {
                NavigationStack {
                    VStack {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.yellow)
                            .frame(width: 119, height: 140)
                        Text("당근")
                            .foregroundColor(.secondary)
                            .offset(y: -45)
                    }
                    .toolbar {
                        VStack{
                            Button("Close", role: .cancel){
                                sheet.toggle()
                            }
                            Button("Close", role: .cancel){
                                sheet.toggle()
                            }
                    
                        }
                    }
                } //End: NavigationStack
            } //End: sheet
        }
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        FoodsSheet()
    }
}


