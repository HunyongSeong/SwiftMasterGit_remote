//
//  BookFruit.swift
//  DinoDina
//
//  Created by David Goggins on 2023/05/08.
//

import SwiftUI

struct BookFruit: View {
    let columns = [
        //                GridItem(.adaptive(minimum: 100))
        //                GridItem(.flexible(), spacing: -10),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    var body: some View {
        NavigationView {
            ScrollView {
                VStack{
                    
                    HStack {
                        Text("나의 과일")
                        //                            .offset(x: -245, y: 0)
                            .font(.system(size: 47, weight: .semibold))
                            .padding(.top, 35)
                        NavigationLink(destination: ContentView()){
                            Text("야채")
                                .font(.system(size: 23, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 101, height: 42, alignment: .center)
                                .background(Color(red: 65/255, green: 175/255, blue: 57/255))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.black, lineWidth: 2)
                                )
                        }
                        NavigationLink(destination: ContentView()){
                            Text("과일")
                                .font(.system(size: 23, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 101, height: 42, alignment: .center)
                                .background(Color(red: 226/255, green: 0/255, blue: 0/255))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.black, lineWidth: 2)
                                )
                        }
                        NavigationLink(destination: ContentView()){
                            Text("고기")
                                .font(.system(size: 23, weight: .semibold))
                                .foregroundColor(.black)
                                .frame(width: 101, height: 42, alignment: .center)
                                .background(Color(red: 255/255, green: 186/255, blue: 0/255))
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.black, lineWidth: 2)
                                )
                        }
                        NavigationLink(destination: ContentView()){
                            Image("BackButton")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: 64.42, height: 64.42, alignment: .center)
                                .foregroundColor(.blue)
                                .imageScale(.large)
                                .foregroundColor(.accentColor)
                        }// End NavigationLink
                        
                    }// End HStack
                    
                    NavigationLink(destination: BookDetailView()){ // Rect
                        LazyVGrid(columns: columns, spacing: 0) {
                            ForEach(Fruit.allFruit, id: \.self) { FruitNum in
                                VStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(Color(red: 255/255, green: 186/255, blue: 0/255, opacity: 0.15))
                                        .overlay( // 뷰를 겹치게 하여 border 설정, 라운드 처리를 할 경우 overlay를 통해 border 처리를 해주어야 한다.
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(Color(red: 255/255, green: 186/255, blue: 0/255), lineWidth: 1.5)
                                        )
                                        .frame(width: 119, height: 140)
                                    Text(Fruit.allFruit[FruitNum.id-1].name)
                                        .font(.system(size: 20))
                                        .foregroundColor(.black)
                                        .frame(width: 97, height: 31, alignment: .top)
                                        .background(Color.white.opacity(0.75))
                                        .cornerRadius(8)
                                        .font(.subheadline)
                                        .offset(y: -47)
                                    Text(Fruit.allFruit[FruitNum.id-1].illust)
                                        .offset(y: -130)
                                } // End: VStack
                            } // End: LazyVGrid
                        } // End: NavigationLink
                        .padding(.horizontal)
                        .padding(.horizontal)
                    }// End: NavigationLink
                }
            }
        }
    }
}

struct BookFruit_Previews: PreviewProvider {
    static var previews: some View {
        BookFruit()
    }
}
