//
//  BookDetailView.swift
//  DinoDina
//
//  Created by David Goggins on 2023/05/04.
//

import SwiftUI

struct BookDetailView: View {
    var body: some View {
        VStack{
            ForEach(Fruit.allFruit, id: \.self) { FruitNum in
                Text("This is Detail View")
                    .font(.largeTitle)
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.yellow)
                    .frame(width: 300, height: 300)
                Text("바니바니")
                    .font(.system(size: 24))
                    .offset(y: -60)
            }
        } //End VStack
    }
}

struct BookDetailView_Previews: PreviewProvider {
    static var previews: some View {
        BookDetailView()
    }
}
